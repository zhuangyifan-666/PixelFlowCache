# Stage 4A FID Summary

| model | method | images | steps | speedup | FID | IS | cache hit |
|---|---|---:|---:|---:|---:|---:|---:|
| DeCo | bfc_all_candidates_t02_10 | 100 | 50 | 1.4921998889345207 | None | None | 0.4 |
| DeCo | bfc_backbone_plus_final_t02_10 | 100 | 50 | 0.8344903963935281 | None | None | 0.4 |
| DeCo | no_cache_50 | 100 | 50 | 1.0 | None | None | 0.0 |
| DeCo | reduced_steps_30 | 100 | 30 | 1.5755670326282405 | None | None | 0.0 |
| DeCo | reduced_steps_35 | 100 | 35 | 1.389783123666486 | None | None | 0.0 |
| JiT | bfc_quality_t02_08 | 100 | 50 | 1.6600970523800314 | None | None | 0.3 |
| JiT | bfc_speed_t02_10 | 100 | 50 | 1.7820261228511824 | None | None | 0.4 |
| JiT | no_cache_50 | 100 | 50 | 1.0 | None | None | 0.0 |
| JiT | reduced_steps_30 | 100 | 30 | 1.7823792422423612 | None | None | 0.0 |
| JiT | reduced_steps_35 | 100 | 35 | 1.6323510792627005 | None | None | 0.0 |
