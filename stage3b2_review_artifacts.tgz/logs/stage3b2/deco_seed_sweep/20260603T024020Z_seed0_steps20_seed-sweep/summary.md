# DeCo Stage 3B2 Seed Sweep

| method | type | speedup mean | rel-L2 mean | hit rate | final | backbone | decoder |
|---|---|---:|---:|---:|---|---|---|
| all_candidates | cache | 1.5987 | 0.068835 | 0.4000 | True | True | True |
| backbone_only | cache | 1.4541 | 0.155953 | 0.4000 | False | True | False |
| backbone_plus_final | cache | 1.4893 | 0.068835 | 0.4000 | True | True | False |
| final_only | cache | 1.0048 | 0.068835 | 0.4000 | True | False | False |
| no_cache | reference | 1.0000 | 0.000000 | 0.0000 | False | False | False |
| reduced_steps_12 | reduced_steps | 1.6595 | 0.241067 | 0.0000 | False | False | False |
