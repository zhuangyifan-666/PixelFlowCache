# DeCo Stage 3B2 50-Step Validation

| method | type | speedup mean | rel-L2 mean | hit rate | final | backbone | decoder |
|---|---|---:|---:|---:|---|---|---|
| all_candidates | cache | 1.6009 | 0.045969 | 0.4000 | True | True | True |
| backbone_only | cache | 1.4627 | 0.069294 | 0.4000 | False | True | False |
| backbone_plus_final | cache | 1.4844 | 0.045969 | 0.4000 | True | True | False |
| decoder_plus_final | cache | 1.0569 | 0.045969 | 0.4000 | True | False | True |
| final_only | cache | 1.0030 | 0.045969 | 0.4000 | True | False | False |
| no_cache | reference | 1.0000 | 0.000000 | 0.0000 | False | False | False |
| reduced_steps_30 | reduced_steps | 1.6553 | 0.253003 | 0.0000 | False | False | False |
| reduced_steps_35 | reduced_steps | 1.4189 | 0.224557 | 0.0000 | False | False | False |
| reduced_steps_40 | reduced_steps | 1.2448 | 0.185199 | 0.0000 | False | False | False |
