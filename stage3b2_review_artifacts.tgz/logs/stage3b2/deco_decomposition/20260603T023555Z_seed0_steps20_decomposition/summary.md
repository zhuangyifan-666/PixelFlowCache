# DeCo Stage 3B2 Cache Decomposition

| method | type | speedup mean | rel-L2 mean | hit rate | final | backbone | decoder |
|---|---|---:|---:|---:|---|---|---|
| all_candidates | cache | 1.1313 | 0.072756 | 0.4000 | True | True | True |
| backbone_only | cache | 1.0028 | 0.154051 | 0.4000 | False | True | False |
| backbone_plus_decoder_no_final | cache | 1.1320 | 0.072756 | 0.4000 | False | True | True |
| backbone_plus_final | cache | 1.0987 | 0.072756 | 0.4000 | True | True | False |
| decoder_only_no_final | cache | 0.8642 | 0.072756 | 0.4000 | False | False | True |
| decoder_plus_final | cache | 0.8502 | 0.072756 | 0.4000 | True | False | True |
| final_only | cache | 0.8499 | 0.072756 | 0.4000 | True | False | False |
| late_backbone_only_6 | cache | 0.8430 | 0.154051 | 0.4000 | False | True | False |
| late_backbone_plus_final_6 | cache | 0.8753 | 0.072756 | 0.4000 | True | True | False |
| no_cache | reference | 1.0000 | 0.000000 | 0.0000 | False | False | False |
| reduced_steps_12 | reduced_steps | 1.6698 | 0.259579 | 0.0000 | False | False | False |
| reduced_steps_15 | reduced_steps | 1.3489 | 0.210121 | 0.0000 | False | False | False |
| reduced_steps_18 | reduced_steps | 1.1202 | 0.139081 | 0.0000 | False | False | False |
