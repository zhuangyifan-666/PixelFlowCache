# paper_table_deco_decomposition

| method | type | speedup | rel-L2 | PSNR | hit rate | final | backbone | decoder | notes |
|---|---|---:|---:|---:|---:|---|---|---|---|
| all_candidates | cache | 1.1312816486456072 | 0.07275560492974514 | 36.953810732269304 | 0.4 | True | True | True | closest reduced-step: reduced_steps_18 speedup 1.120 rel-L2 0.1391 |
| backbone_only | cache | 1.0027847077293575 | 0.15405067125765598 | 30.4376697076962 | 0.4 | False | True | False | closest reduced-step: reduced_steps_18 speedup 1.120 rel-L2 0.1391 |
| backbone_plus_final | cache | 1.0986891815529323 | 0.07275560492974514 | 36.953810732269304 | 0.4 | True | True | False | closest reduced-step: reduced_steps_18 speedup 1.120 rel-L2 0.1391 |
| final_only | cache | 0.849913125311082 | 0.07275560492974514 | 36.953810732269304 | 0.4 | True | False | False | closest reduced-step: reduced_steps_18 speedup 1.120 rel-L2 0.1391 |
| reduced_steps_12 | reduced_steps | 1.6697769396723827 | 0.259579415222321 | 25.905357285857455 | 0.0 | False | False | False |  |
| reduced_steps_15 | reduced_steps | 1.3488791456638125 | 0.21012067865027906 | 27.741331002485715 | 0.0 | False | False | False |  |
| reduced_steps_18 | reduced_steps | 1.120207728469677 | 0.13908062509427777 | 31.325494083697812 | 0.0 | False | False | False |  |
