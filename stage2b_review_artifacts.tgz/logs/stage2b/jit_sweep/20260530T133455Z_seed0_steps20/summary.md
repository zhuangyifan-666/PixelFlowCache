# JiT Stage 2B Sweep

| layers | interval | t min | t max | speedup | hit rate | rel-L2 |
|---|---:|---:|---:|---:|---:|---:|
| all | 2 | 0.1 | 1.0 | 1.7517 | 0.4500 | 0.091249 |
| all | 2 | 0.1 | 0.8 | 1.4890 | 0.3500 | 0.080710 |
| prefix:6 | 2 | 0.1 | 0.8 | 1.1800 | 0.3500 | 0.150008 |
| suffix:6 | 2 | 0.1 | 0.8 | 1.2118 | 0.3500 | 0.080710 |
| middle | 2 | 0.1 | 0.8 | 1.2022 | 0.3500 | 0.151906 |
| all | 3 | 0.1 | 0.8 | 1.7360 | 0.4500 | 0.172929 |

Best rel-L2 row: `/mnt/iset/nfs-main/private/zhuangyifan/PixelFlowCache/logs/stage2b/jit_sweep/20260530T133455Z_seed0_steps20/runs/20260530T133455Z_seed0_steps20_all_i2_t0p1-0p8`
