# JiT Stage 3A BackboneCache Benchmark

| method | type | speedup mean | rel-L2 mean | rel-L2 std | hit rate |
|---|---|---:|---:|---:|---:|
| aggressive_i3_t02_08 | cache | 1.5533 | 0.033563 | 0.006292 | 0.3800 |
| no_cache | reference | 1.0000 | 0.000000 | 0.000000 | 0.0000 |
| quality_t01_08_w1 | cache | 1.4307 | 0.029174 | 0.006232 | 0.3200 |
| quality_t01_08_w2 | cache | 1.3909 | 0.022393 | 0.006337 | 0.3000 |
| quality_t02_08 | cache | 1.3965 | 0.022393 | 0.006337 | 0.3000 |
| reduced_steps_30 | reduced_steps | 1.6607 | 0.181010 | 0.020302 | 0.0000 |
| reduced_steps_35 | reduced_steps | 1.4237 | 0.133187 | 0.017465 | 0.0000 |
| reduced_steps_40 | reduced_steps | 1.2445 | 0.111390 | 0.017743 | 0.0000 |
| speed_t02_10 | cache | 1.6072 | 0.027789 | 0.005509 | 0.4000 |
