# Stage 3A JiT BackboneCache Report Table

| method | type | speedup mean | rel-L2 mean | rel-L2 std | PSNR mean | hit rate | notes |
|---|---|---:|---:|---:|---:|---:|---|
| aggressive_i3_t02_08 | cache | 1.5532975345569342 | 0.03356317120293776 | 0.006292108600705148 | 42.646994010584756 | 0.38000000000000006 | closest reduced-step speed: reduced_steps_30 (speedup 1.661, rel-L2 0.1810) |
| no_cache | reference | 1.0 | 0.0 | 0.0 |  | 0.0 |  |
| quality_t01_08_w1 | cache | 1.4307442378746031 | 0.029174188772837322 | 0.00623178942781915 | 43.900430715122305 | 0.32 | closest reduced-step speed: reduced_steps_35 (speedup 1.424, rel-L2 0.1332) |
| quality_t01_08_w2 | cache | 1.3908603217749966 | 0.02239266720910867 | 0.006336701265413685 | 46.34358126527579 | 0.3 | closest reduced-step speed: reduced_steps_35 (speedup 1.424, rel-L2 0.1332) |
| quality_t02_08 | cache | 1.3964654285481144 | 0.02239266720910867 | 0.006336701265413685 | 46.34358126527579 | 0.3 | Quality-first BackboneCache. closest reduced-step speed: reduced_steps_35 (speedup 1.424, rel-L2 0.1332) |
| reduced_steps_30 | reduced_steps | 1.6607405094273444 | 0.18101029098033905 | 0.020301552447523553 | 27.911561566578982 | 0.0 |  |
| reduced_steps_35 | reduced_steps | 1.42370909178965 | 0.13318655888239542 | 0.01746473498362769 | 30.595644934843836 | 0.0 |  |
| reduced_steps_40 | reduced_steps | 1.2445112092088153 | 0.11139030506213506 | 0.017742526527046304 | 32.19240695177874 | 0.0 |  |
| speed_t02_10 | cache | 1.6071629707320383 | 0.027789081757267315 | 0.005509483451021845 | 44.29683669342427 | 0.4000000000000001 | Speed-quality BackboneCache. closest reduced-step speed: reduced_steps_30 (speedup 1.661, rel-L2 0.1810) |
