# JiT Stage 2D Best-Window Validation

| layers | interval | t min | t max | speedup | hit rate | rel-L2 |
|---|---:|---:|---:|---:|---:|---:|
| none | 1 | None | None | 0.9854 | 0.0000 | 0.000000 |
| all | 2 | 0.1 | 0.8 | 1.4677 | 0.3400 | 0.040435 |
| all | 2 | 0.1 | 1.0 | 1.7097 | 0.4400 | 0.043077 |
| all | 2 | 0.2 | 0.8 | 1.3913 | 0.3000 | 0.019059 |
| all | 2 | 0.2 | 1.0 | 1.6079 | 0.4000 | 0.024648 |
| all | 3 | 0.2 | 0.8 | 1.5560 | 0.3800 | 0.030535 |

Best quality row: `all/i2 [0.2,0.8)` run=`/mnt/iset/nfs-main/private/zhuangyifan/PixelFlowCache/logs/stage2d/jit_validate_best/20260601T054448Z_seed0_steps50/runs/20260601T054448Z_seed0_steps50_all_i2_t0p2-0p8`
Fastest row: `all/i2 [0.1,1.0)` run=`/mnt/iset/nfs-main/private/zhuangyifan/PixelFlowCache/logs/stage2d/jit_validate_best/20260601T054448Z_seed0_steps50/runs/20260601T054448Z_seed0_steps50_all_i2_t0p1-1p0`
