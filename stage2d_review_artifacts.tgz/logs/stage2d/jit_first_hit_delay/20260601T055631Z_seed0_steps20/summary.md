# JiT Stage 2D First-Hit Delay

| warmup refreshes | speedup | hit rate | rel-L2 | PSNR |
|---:|---:|---:|---:|---:|
| 0 | 1.4904 | 0.3500 | 0.080710 | 35.5995 |
| 1 | 1.3975 | 0.3000 | 0.032933 | 43.3857 |
| 2 | 1.3063 | 0.2500 | 0.022872 | 46.5522 |

Best quality warmup refreshes: `2`
Fastest warmup refreshes: `0`
