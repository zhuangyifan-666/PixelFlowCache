# JiT Stage 2 Fixed-Interval Block Cache Grid

| layers | interval | speedup | hit rate | rel-L2 | run dir |
|---|---:|---:|---:|---:|---|
| none | 1 | 0.9990 | 0.0000 | 0.000000 | `/mnt/iset/nfs-main/private/zhuangyifan/PixelFlowCache/logs/stage2/jit_grid/20260530T125718Z_seed0_steps20/runs/20260530T125718Z_seed0_steps20_none_i1` |
| middle | 2 | 1.3248 | 0.5000 | 0.420487 | `/mnt/iset/nfs-main/private/zhuangyifan/PixelFlowCache/logs/stage2/jit_grid/20260530T125718Z_seed0_steps20/runs/20260530T125718Z_seed0_steps20_middle_i2` |
| middle | 3 | 1.4637 | 0.6500 | 0.551204 | `/mnt/iset/nfs-main/private/zhuangyifan/PixelFlowCache/logs/stage2/jit_grid/20260530T125718Z_seed0_steps20/runs/20260530T125718Z_seed0_steps20_middle_i3` |
| all | 2 | 1.8887 | 0.5000 | 0.259229 | `/mnt/iset/nfs-main/private/zhuangyifan/PixelFlowCache/logs/stage2/jit_grid/20260530T125718Z_seed0_steps20/runs/20260530T125718Z_seed0_steps20_all_i2` |
