# Stage 3C Unified BoundaryFlowCache Summary

Stage 3C consolidates existing JiT Stage 3A and DeCo Stage 3B2 results. It does not add token cache, adaptive policy, calibration, or new model execution.

## Best Current Rows

- JiT quality preset `quality_t02_08`: speedup 1.396x, rel-L2 0.0224.
- JiT speed preset `speed_t02_10`: speedup 1.607x, rel-L2 0.0278.
- DeCo `all_candidates`: speedup 1.601x, rel-L2 0.0460.
- DeCo `backbone_plus_final`: speedup 1.484x, rel-L2 0.0460.
- DeCo `final_only`: speedup 1.003x, rel-L2 0.0460.

## Cache Versus Reduced Steps

Closest reduced-step matches are selected by absolute speedup difference within the same model and source run.
- JiT `quality_t02_08` vs `reduced_steps_35`: cache rel-L2 0.0224, reduced rel-L2 0.1332, rel-L2 advantage 0.1108.
- JiT `speed_t02_10` vs `reduced_steps_30`: cache rel-L2 0.0278, reduced rel-L2 0.1810, rel-L2 advantage 0.1532.
- DeCo `all_candidates` vs `reduced_steps_30`: cache rel-L2 0.0460, reduced rel-L2 0.2530, rel-L2 advantage 0.2070.
- DeCo `backbone_only` vs `reduced_steps_35`: cache rel-L2 0.0693, reduced rel-L2 0.2246, rel-L2 advantage 0.1553.
- DeCo `backbone_plus_final` vs `reduced_steps_35`: cache rel-L2 0.0460, reduced rel-L2 0.2246, rel-L2 advantage 0.1786.
- DeCo `final_only` vs `reduced_steps_40`: cache rel-L2 0.0460, reduced rel-L2 0.1852, rel-L2 advantage 0.1392.
- DeCo `all_candidates` vs `reduced_steps_12`: cache rel-L2 0.0688, reduced rel-L2 0.2411, rel-L2 advantage 0.1722.
- DeCo `backbone_only` vs `reduced_steps_12`: cache rel-L2 0.1560, reduced rel-L2 0.2411, rel-L2 advantage 0.0851.
- DeCo `backbone_plus_final` vs `reduced_steps_12`: cache rel-L2 0.0688, reduced rel-L2 0.2411, rel-L2 advantage 0.1722.
- DeCo `final_only` vs `reduced_steps_12`: cache rel-L2 0.0688, reduced rel-L2 0.2411, rel-L2 advantage 0.1722.
- DeCo `all_candidates` vs `reduced_steps_18`: cache rel-L2 0.0728, reduced rel-L2 0.1391, rel-L2 advantage 0.0663.
- DeCo `backbone_only` vs `reduced_steps_18`: cache rel-L2 0.1541, reduced rel-L2 0.1391, rel-L2 advantage -0.0150.
- DeCo `backbone_plus_final` vs `reduced_steps_18`: cache rel-L2 0.0728, reduced rel-L2 0.1391, rel-L2 advantage 0.0663.
- DeCo `final_only` vs `reduced_steps_18`: cache rel-L2 0.0728, reduced rel-L2 0.1391, rel-L2 advantage 0.0663.
