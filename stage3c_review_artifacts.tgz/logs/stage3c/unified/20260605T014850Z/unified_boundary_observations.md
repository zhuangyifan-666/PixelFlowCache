# Stage 3C Boundary Observations

1. Pixel-space flow cache is boundary-sensitive. Whole-block reuse acts through the point where stale features overwrite the fresh trajectory.
2. JiT x-pred benefits from a whole-backbone boundary cache with early-step suppression; the best debug presets avoid the most unstable high-noise region.
3. DeCo v-pred quality is controlled by the final/output velocity boundary. Backbone and decoder cache mainly add speed when paired with that output boundary.
4. Cache preserves the full-step trajectory better than fewer-step no-cache sampling at similar speed in the current same-seed diagnostics.

These observations support the working method name `BoundaryFlowCache`.
