# Stage 3C Main Cache Vs Reduced-Step Table

| model | method | type | speedup | rel-L2 | PSNR | hit rate | prediction type | note |
|---|---|---|---|---|---|---|---|---|
| JiT | quality_t02_08 | cache | 1.396 | 0.0224 | 46.34 | 0.300 | xpred | BackboneCache quality preset. |
| JiT | reduced_steps_35 | reduced_steps | 1.424 | 0.1332 | 30.60 | 0.000 | xpred | Closest reduced-step match for `quality_t02_08`. |
| JiT | speed_t02_10 | cache | 1.607 | 0.0278 | 44.30 | 0.400 | xpred | BackboneCache speed preset. |
| JiT | reduced_steps_30 | reduced_steps | 1.661 | 0.1810 | 27.91 | 0.000 | xpred | Closest reduced-step match for `speed_t02_10`. |
| DeCo | all_candidates | cache | 1.601 | 0.0460 | 39.63 | 0.400 | vpred | Output plus backbone/decoder boundary cache. |
| DeCo | reduced_steps_30 | reduced_steps | 1.655 | 0.2530 | 24.82 | 0.000 | vpred | Closest reduced-step match for `all_candidates`. |
| DeCo | backbone_plus_final | cache | 1.484 | 0.0460 | 39.63 | 0.400 | vpred | Backbone plus final/output boundary cache. |
| DeCo | final_only | cache | 1.003 | 0.0460 | 39.63 | 0.400 | vpred | Final/output boundary only. |
| DeCo | backbone_only | cache | 1.463 | 0.0693 | 36.07 | 0.400 | vpred | Backbone boundary without final/output cache. |
