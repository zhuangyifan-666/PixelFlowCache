# Stage 3C Boundary Ablation Table

| model | method | type | speedup | rel-L2 | PSNR | hit rate | prediction type | note |
|---|---|---|---|---|---|---|---|---|
| DeCo | all_candidates | cache | 1.131 | 0.0728 | 36.95 | 0.400 | vpred | source=deco_decomposition; boundary=all_candidates |
| DeCo | backbone_only | cache | 1.003 | 0.1541 | 30.44 | 0.400 | vpred | source=deco_decomposition; boundary=backbone_only |
| DeCo | late_backbone_only_6 | cache | 0.843 | 0.1541 | 30.44 | 0.400 | vpred | source=deco_decomposition; boundary=backbone_only |
| DeCo | backbone_plus_decoder_no_final | cache | 1.132 | 0.0728 | 36.95 | 0.400 | vpred | source=deco_decomposition; boundary=backbone_plus_decoder |
| DeCo | backbone_plus_final | cache | 1.099 | 0.0728 | 36.95 | 0.400 | vpred | source=deco_decomposition; boundary=backbone_plus_final |
| DeCo | late_backbone_plus_final_6 | cache | 0.875 | 0.0728 | 36.95 | 0.400 | vpred | source=deco_decomposition; boundary=backbone_plus_final |
| DeCo | decoder_only_no_final | cache | 0.864 | 0.0728 | 36.95 | 0.400 | vpred | source=deco_decomposition; boundary=decoder |
| DeCo | decoder_plus_final | cache | 0.850 | 0.0728 | 36.95 | 0.400 | vpred | source=deco_decomposition; boundary=output_final |
| DeCo | final_only | cache | 0.850 | 0.0728 | 36.95 | 0.400 | vpred | source=deco_decomposition; boundary=output_final |
| DeCo | all_candidates | cache | 1.601 | 0.0460 | 39.63 | 0.400 | vpred | source=deco_validation; boundary=all_candidates |
| DeCo | backbone_only | cache | 1.463 | 0.0693 | 36.07 | 0.400 | vpred | source=deco_validation; boundary=backbone_only |
| DeCo | backbone_plus_final | cache | 1.484 | 0.0460 | 39.63 | 0.400 | vpred | source=deco_validation; boundary=backbone_plus_final |
| DeCo | decoder_plus_final | cache | 1.057 | 0.0460 | 39.63 | 0.400 | vpred | source=deco_validation; boundary=output_final |
| DeCo | final_only | cache | 1.003 | 0.0460 | 39.63 | 0.400 | vpred | source=deco_validation; boundary=output_final |
