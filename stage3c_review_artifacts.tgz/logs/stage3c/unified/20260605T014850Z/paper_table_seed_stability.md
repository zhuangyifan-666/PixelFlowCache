# Stage 3C Seed Stability Table

| model | method | type | speedup | rel-L2 | PSNR | hit rate | prediction type | note |
|---|---|---|---|---|---|---|---|---|
| DeCo | all_candidates | cache | 1.599 | 0.0688 | 37.99 | 0.400 | vpred | seed_count=3; source=deco_seed_sweep; speedup_std=0.0049; rel_l2_std=0.0044 |
| DeCo | backbone_only | cache | 1.454 | 0.1560 | 30.87 | 0.400 | vpred | seed_count=3; source=deco_seed_sweep; speedup_std=0.0149; rel_l2_std=0.0040 |
| DeCo | backbone_plus_final | cache | 1.489 | 0.0688 | 37.99 | 0.400 | vpred | seed_count=3; source=deco_seed_sweep; speedup_std=0.0038; rel_l2_std=0.0044 |
| DeCo | final_only | cache | 1.005 | 0.0688 | 37.99 | 0.400 | vpred | seed_count=3; source=deco_seed_sweep; speedup_std=0.0025; rel_l2_std=0.0044 |
| JiT | quality_t02_08 | cache | 1.396 | 0.0224 | 46.34 | 0.300 | xpred | seed_count=3; source=jit_stage3a; speedup_std=0.0013; rel_l2_std=0.0063 |
| JiT | speed_t02_10 | cache | 1.607 | 0.0278 | 44.30 | 0.400 | xpred | seed_count=3; source=jit_stage3a; speedup_std=0.0010; rel_l2_std=0.0055 |
