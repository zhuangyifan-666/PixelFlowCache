# DeCo Stage 3B Direct-Velocity Cache Benchmark

| method | type | speedup mean | rel-L2 mean | rel-L2 std | hit rate |
|---|---|---:|---:|---:|---:|
| all_candidates_i2_t02_10 | cache | 1.5928 | 0.072756 | 0.000000 | 0.4000 |
| backbone_i2_t02_08 | cache | 1.3172 | 0.102509 | 0.000000 | 0.3000 |
| backbone_i2_t02_10 | cache | 1.4727 | 0.154051 | 0.000000 | 0.4000 |
| decoder_i2_t02_10 | cache | 1.0511 | 0.072756 | 0.000000 | 0.4000 |
| final_i2_t02_10 | cache | 1.0089 | 0.072756 | 0.000000 | 0.4000 |
| no_cache | reference | 1.0000 | 0.000000 | 0.000000 | 0.0000 |
| reduced_steps_12 | reduced_steps | 1.6530 | 0.259579 | 0.000000 | 0.0000 |
| reduced_steps_15 | reduced_steps | 1.3285 | 0.210121 | 0.000000 | 0.0000 |
| reduced_steps_18 | reduced_steps | 1.1069 | 0.139081 | 0.000000 | 0.0000 |
