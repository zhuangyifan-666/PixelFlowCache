# DeCo Stage 3B Cache Feasibility

- cache units: `backbone_blocks`
- wrapped modules: 28
- no-cache median latency: 2.9645s
- cache median latency: 2.7727s
- speedup: 1.0692
- cache hit rate: 0.4000
- same-seed rel-L2: 0.154051
- same-seed MSE: 0.00361654
- same-seed PSNR: 30.4377
