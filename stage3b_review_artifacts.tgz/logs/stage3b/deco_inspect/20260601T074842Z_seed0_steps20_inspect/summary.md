# DeCo Stage 3B Cache Unit Inspection

- run dir: `/mnt/iset/nfs-main/private/zhuangyifan/PixelFlowCache/logs/stage3b/deco_inspect/20260601T074842Z_seed0_steps20_inspect`
- module count: 496
- listed candidates: 427
- cacheable block-level units: 32

| category | count |
|---|---:|
| backbone_block | 28 |
| decoder_block | 3 |
| final_head | 1 |
| norm_or_modulation | 179 |
| tiny_module | 216 |
