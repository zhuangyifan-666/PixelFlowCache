# JiT Stage 2C Validation

| layers | t min | t max | interval | speedup | hit rate | rel-L2 |
|---|---:|---:|---:|---:|---:|---:|
| none | None | None | 1 | 0.9911 | 0.0000 | 0.000000 |
| all | 0.1 | 0.8 | 2 | 1.4687 | 0.3400 | 0.040435 |
| all | 0.1 | 1.0 | 2 | 1.7079 | 0.4400 | 0.043077 |
| all | 0.1 | 0.8 | 3 | 1.7060 | 0.4400 | 0.070958 |
