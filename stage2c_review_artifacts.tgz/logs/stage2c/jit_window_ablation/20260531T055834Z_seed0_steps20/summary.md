# JiT Stage 2C Window Ablation

| group | t min | t max | interval | speedup | hit rate | rel-L2 |
|---|---:|---:|---:|---:|---:|---:|
| t_min | 0.0 | 0.8 | 2 | 1.5950 | 0.4000 | 0.250180 |
| t_min | 0.05 | 0.8 | 2 | 1.6157 | 0.4000 | 0.250180 |
| t_min | 0.1 | 0.8 | 2 | 1.4880 | 0.3500 | 0.080710 |
| t_min | 0.2 | 0.8 | 2 | 1.3894 | 0.3000 | 0.032933 |
| t_max | 0.1 | 0.7 | 2 | 1.3934 | 0.3000 | 0.079128 |
| t_max | 0.1 | 0.8 | 2 | 1.4880 | 0.3500 | 0.080710 |
| t_max | 0.1 | 0.9 | 2 | 1.6064 | 0.4000 | 0.082998 |
| t_max | 0.1 | 1.0 | 2 | 1.7304 | 0.4500 | 0.091249 |
| interval | 0.2 | 0.8 | 2 | 1.3894 | 0.3000 | 0.032933 |
| interval | 0.2 | 0.8 | 3 | 1.6055 | 0.4000 | 0.080137 |

Best same-seed rel-L2 row: `t_min` t=[0.2, 0.8) interval=2 run=`/mnt/iset/nfs-main/private/zhuangyifan/PixelFlowCache/logs/stage2c/jit_window_ablation/20260531T055834Z_seed0_steps20/runs/20260531T055834Z_seed0_steps20_all_i2_t0p2-0p8`
Fastest row: `t_max` t=[0.1, 1.0) interval=2 run=`/mnt/iset/nfs-main/private/zhuangyifan/PixelFlowCache/logs/stage2c/jit_window_ablation/20260531T055834Z_seed0_steps20/runs/20260531T055834Z_seed0_steps20_all_i2_t0p1-1p0`
